import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import Terms from "./pages/Terms";
import FairHousing from "./pages/FairHousing";
import WorkshopDraft from "./pages/WorkshopDraft";
import JoinUs from "./pages/JoinUs";
import Coaching from "./pages/Coaching";
import Accessibility from "./pages/Accessibility";
import DenverHomesForSale from "./pages/DenverHomesForSale";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/privacy"} component={PrivacyPolicy} />
      <Route path={"/terms"} component={Terms} />
      <Route path={"/fair-housing"} component={FairHousing} />
      <Route path={"/colorado-home-buying-workshop"} component={WorkshopDraft} />
      <Route path={"/join-us"} component={JoinUs} />
      <Route path={"/real-estate-coaching"} component={Coaching} />
      <Route path={"/coaching"}>{() => { window.location.href = "/real-estate-coaching"; return null; }}</Route>
      <Route path={"/accessibility"} component={Accessibility} />
      <Route path={"/denver-homes-for-sale"} component={DenverHomesForSale} />
      <Route path={"/workshop-draft"}>{() => { window.location.href = "/colorado-home-buying-workshop"; return null; }}</Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
